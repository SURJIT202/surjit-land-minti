var CACHE='zameennaap-v4';
var ASSETS=['./','./index.html','./manifest.webmanifest','./icon-192.png','./icon-512.png'];
self.addEventListener('install',function(e){
  e.waitUntil(caches.open(CACHE).then(function(c){return c.addAll(ASSETS);}));
  self.skipWaiting();
});
self.addEventListener('activate',function(e){
  e.waitUntil(caches.keys().then(function(ks){
    return Promise.all(ks.filter(function(k){return k!==CACHE;}).map(function(k){return caches.delete(k);}));
  }));
});
self.addEventListener('fetch',function(e){
  if(e.request.method!=='GET') return;
  e.respondWith(
    caches.match(e.request,{ignoreSearch:true}).then(function(r){
      if(r) return r;
      return fetch(e.request).then(function(resp){
        try{
          if(resp.ok && new URL(e.request.url).origin===self.location.origin){
            var copy=resp.clone();
            caches.open(CACHE).then(function(c){c.put(e.request,copy);});
          }
        }catch(err){}
        return resp;
      }).catch(function(){
        return caches.match('./index.html');
      });
    })
  );
});
